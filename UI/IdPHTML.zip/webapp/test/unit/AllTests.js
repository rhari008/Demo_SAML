sap.ui.define([
	"com/sample/IdPHTML/test/unit/controller/View1.controller"
], function () {
	"use strict";
});